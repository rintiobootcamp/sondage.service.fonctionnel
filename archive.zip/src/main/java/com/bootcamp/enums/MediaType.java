package com.bootcamp.enums;

/**
 * Created by darextossa on 11/26/17.
 */
public enum MediaType {
    IMAGE,
    AUDIO,
    VIDEO
}
