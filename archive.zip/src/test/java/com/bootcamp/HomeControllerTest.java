package com.bootcamp;


import org.testng.Assert;
import org.testng.annotations.Test;

/**
 * Unit test for simple App.
 */
public class HomeControllerTest {

    @Test
    public HomeControllerTest( )
    {
        Assert.assertTrue(true);
    }


}
